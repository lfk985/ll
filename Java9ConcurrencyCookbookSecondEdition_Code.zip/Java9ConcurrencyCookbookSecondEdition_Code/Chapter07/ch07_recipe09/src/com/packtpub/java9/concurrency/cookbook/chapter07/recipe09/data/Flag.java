package com.packtpub.java9.concurrency.cookbook.chapter07.recipe09.data;

public class Flag {
	
	public boolean flag=true;

}
