package com.packtpub.java9.concurrency.cookbook.chapter07.recipe09.data;

public class VolatileFlag {
	
	public volatile boolean flag=true;

}
