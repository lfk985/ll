package com.packtpub.java9.concurrency.cookbook.chapter07.recipe09.data;

public class Account {

	public double amount;
	
	public double unsafeAmount;
	
	public Account() {
		this.amount=0;
		this.unsafeAmount=0;
	}
}
