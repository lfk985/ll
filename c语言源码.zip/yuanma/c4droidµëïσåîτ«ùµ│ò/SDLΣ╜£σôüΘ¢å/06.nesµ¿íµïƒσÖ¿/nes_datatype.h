#ifndef _NES_DATATYPE_H_
#define _NES_DATATYPE_H_
 
typedef unsigned short WORD;
//typedef unsigned char  BYTE;
typedef  unsigned char BYTE;
//typedef unsigned short  WORD;
typedef unsigned long   DWORD;
typedef  int  DU16;
typedef  unsigned short U16;
typedef  int BOOL;
typedef  unsigned char U8;
typedef  unsigned long int  U32;

#endif