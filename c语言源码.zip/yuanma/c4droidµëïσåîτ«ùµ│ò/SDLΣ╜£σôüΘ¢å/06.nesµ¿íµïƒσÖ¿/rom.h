#ifndef _ROM_H_
#define _ROM_H_

extern unsigned char*rom_file;

//extern unsigned char*ram_nes;
 
#endif