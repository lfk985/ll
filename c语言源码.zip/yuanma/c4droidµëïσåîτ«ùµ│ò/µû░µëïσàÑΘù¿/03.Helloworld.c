/*c4droid代码手册
 *c++版helloworld
 *注意使用G++编译器
 *TTHHR编写
 *转载请说明出处
*/
#include <iostream>
using namespace std;
int main()
{
cout<<"hello world"<<endl;
return 0;
}