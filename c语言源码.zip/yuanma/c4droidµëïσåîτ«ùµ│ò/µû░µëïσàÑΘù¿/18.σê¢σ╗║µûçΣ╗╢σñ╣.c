﻿/*c4droid代码手册
 *创建文件夹
 *TTHHR编写
 *转载请说明出处
*/

#include<stdlib.h>
int main()
{
system("mkdir /sdcard/新建文件夹");
return 0;
}