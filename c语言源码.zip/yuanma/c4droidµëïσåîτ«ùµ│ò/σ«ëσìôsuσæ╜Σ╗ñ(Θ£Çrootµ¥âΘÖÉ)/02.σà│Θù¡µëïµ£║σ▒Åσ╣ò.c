/*c4droid代码手册
 *关闭手机屏幕
 *TTHHR编写
 *转载请说明出处
*/
#include<stdlib.h>
int main()
{
	system("su -c 'input keyevent 6'");
	return 0;
}