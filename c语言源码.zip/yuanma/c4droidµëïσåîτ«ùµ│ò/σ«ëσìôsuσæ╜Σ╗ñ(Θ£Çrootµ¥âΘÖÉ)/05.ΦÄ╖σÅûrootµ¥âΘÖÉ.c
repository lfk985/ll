﻿/*c4droid代码手册
 *简单终端
 *需要root权限
 *TTHHR编写
 *转载请说明出处
*/
#include<stdlib.h>
int main()
{
	system("su");
return 0;
}