/*c4droid代码手册
 *打开自己用c4droid导出的程序
 *TTHHR编写
 *转载请说明出处
*/
#include<stdlib.h>
int main()
{
	system("am start -n com.temp/com.n0n3m4.apkexport.ExportActivity");//控制台程序com.temp是自己的包名，后面的东西不要修改

	return 0;
}