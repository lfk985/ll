/*c4droid代码手册
 *打开音乐播放器
 *TTHHR编写
 *转载请说明出处
 请以root身份运行！！
*/
#include<stdlib.h>
int main()
{
	system("am start -n	com.android.music/com.android.music.MusicBrowserActivity");
	return 0;
}