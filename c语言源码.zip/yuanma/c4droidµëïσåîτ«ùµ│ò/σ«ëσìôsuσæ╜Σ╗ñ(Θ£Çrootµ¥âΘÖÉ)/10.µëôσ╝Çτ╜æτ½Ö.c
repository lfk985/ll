/*c4droid代码手册
 *打开网站
 *TTHHR编写
 *转载请说明出处
 请以root身份运行！！
*/
#include"stdlib.h"
int main()
{
	system("am start -a android.intent.action.VIEW -d http://m.baidu.com");
}