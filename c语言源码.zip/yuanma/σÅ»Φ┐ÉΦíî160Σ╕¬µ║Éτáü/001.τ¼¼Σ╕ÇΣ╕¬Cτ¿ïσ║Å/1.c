/* 
例程1. Helloworld
整理by:千百度QAIU
QQ:736226400
2017/10/20
*/
#include <stdio.h>				/* 包含标准输入输出头文件 */
int main()						/* 主函数 */
{
		printf("Hello World!\n");	/* 打印输出信息 */
		return 0;           /*运行结束,返回值0*/
}