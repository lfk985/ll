/*
例程2. 运行多个源文件
整理优化by:千百度QAIU
QQ:736226400
编译环境:gcc/tcc
2017/10/20
*/
#include "print.h"
void printHello()
{
	printf("hello word!\n");
}