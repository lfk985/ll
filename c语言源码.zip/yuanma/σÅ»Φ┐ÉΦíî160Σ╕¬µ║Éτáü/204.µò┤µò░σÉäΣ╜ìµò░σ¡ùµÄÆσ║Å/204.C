#include<stdio.h>
#define fuckmain main() \
{printf("fuckmain");}
fuckmain